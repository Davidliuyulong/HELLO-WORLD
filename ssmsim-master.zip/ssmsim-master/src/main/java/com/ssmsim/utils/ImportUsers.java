package com.ssmsim.utils;

public class ImportUsers {

    public static boolean importUsers(String target, String fileName) {
        if(target.equals("user")) {

        } else {

        }
        return true;
    }
}
